﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'sr', {
	alertUrl: 'Унесите УРЛ слике',
	alt: 'Алтернативни текст',
	border: 'Оквир',
	btnUpload: 'Пошаљи на сервер',
	button2Img: 'Do you want to transform the selected image button on a simple image?', // MISSING
	hSpace: 'HSpace',
	img2Button: 'Do you want to transform the selected image on a image button?', // MISSING
	infoTab: 'Инфо слике',
	linkTab: 'Линк',
	lockRatio: 'Закључај однос',
	menu: 'Особине слика',
	resetSize: 'Ресетуј величину',
	title: 'Особине слика',
	titleButton: 'Особине дугмета са сликом',
	upload: 'Пошаљи',
	urlMissing: 'Image source URL is missing.', // MISSING
	vSpace: 'VSpace',
	validateBorder: 'Border must be a whole number.', // MISSING
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
});
