﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'gl', {
	alertUrl: 'Por favor, escriba a URL da imaxe',
	alt: 'Texto Alternativo',
	border: 'Límite',
	btnUpload: 'Enviar ó Servidor',
	button2Img: 'Do you want to transform the selected image button on a simple image?', // MISSING
	hSpace: 'Esp. Horiz.',
	img2Button: 'Do you want to transform the selected image on a image button?', // MISSING
	infoTab: 'Información da Imaxe',
	linkTab: 'Ligazón',
	lockRatio: 'Proporcional',
	menu: 'Propriedades da Imaxe',
	resetSize: 'Tamaño Orixinal',
	title: 'Propriedades da Imaxe',
	titleButton: 'Propriedades do Botón de Imaxe',
	upload: 'Carregar',
	urlMissing: 'Image source URL is missing.', // MISSING
	vSpace: 'Esp. Vert.',
	validateBorder: 'Border must be a whole number.', // MISSING
	validateHSpace: 'HSpace must be a whole number.', // MISSING
	validateVSpace: 'VSpace must be a whole number.' // MISSING
});
