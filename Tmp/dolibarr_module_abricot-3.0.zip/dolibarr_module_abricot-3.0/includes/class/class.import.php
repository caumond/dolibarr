<?php
/*
	Gestion des imports
*/

class Import{
 
	// constructor
	function __Construct(){

	} 

  
	
	
	
		

	

	
} 

