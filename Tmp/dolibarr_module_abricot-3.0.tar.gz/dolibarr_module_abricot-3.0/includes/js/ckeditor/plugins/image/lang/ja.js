﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'ja', {
	alertUrl: 'イメージのURLを入力してください。',
	alt: '代替テキスト',
	border: 'ボーダー',
	btnUpload: 'サーバーに送信',
	button2Img: '選択したボタンを画像に置き換えますか？',
	hSpace: '横間隔',
	img2Button: '選択した画像をボタンに置き換えますか？',
	infoTab: 'イメージ 情報',
	linkTab: 'リンク',
	lockRatio: 'ロック比率',
	menu: 'イメージ プロパティ',
	resetSize: 'サイズリセット',
	title: 'イメージ プロパティ',
	titleButton: '画像ボタン プロパティ',
	upload: 'アップロード',
	urlMissing: 'イメージのURLを入力してください。',
	vSpace: '縦間隔',
	validateBorder: 'ボーダーは数値で入力してください。',
	validateHSpace: '横間隔は数値で入力してください。',
	validateVSpace: '縦間隔は数値で入力してください。'
});
