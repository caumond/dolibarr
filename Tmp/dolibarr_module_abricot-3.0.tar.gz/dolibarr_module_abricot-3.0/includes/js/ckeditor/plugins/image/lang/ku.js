﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image', 'ku', {
	alertUrl: 'تکایه ناونیشانی بهستهری وێنه بنووسه',
	alt: 'جێگرهوهی دهق',
	border: 'پهراوێز',
	btnUpload: 'ناردنی بۆ ڕاژه',
	button2Img: 'تۆ دهتهوێت دوگمهی وێنهی دیاریکراو بگۆڕیت بۆ وێنهکی ئاسایی؟',
	hSpace: 'بۆشایی ئاسۆیی',
	img2Button: 'تۆ دهتهوێت وێنهی دیاریکراو بگۆڕیت بۆ دوگمهی وێنه؟',
	infoTab: 'زانیاری وێنه',
	linkTab: 'بهستهر',
	lockRatio: 'داخستنی ڕێژه',
	menu: 'خاسیهتی وێنه',
	resetSize: 'ڕێکخستنهوهی قهباره',
	title: 'خاسیهتی وێنه',
	titleButton: 'خاسیهتی دوگمهی وێنه',
	upload: 'بارکردن',
	urlMissing: 'سهرچاوهی بهستهری وێنه بزره',
	vSpace: 'بۆشایی ئهستونی',
	validateBorder: 'پهراوێز دهبێت بهتهواوی تهنها ژماره بێت.',
	validateHSpace: 'بۆشایی ئاسۆیی دهبێت بهتهواوی تهنها ژماره بێت.',
	validateVSpace: 'بۆشایی ئهستونی دهبێت بهتهواوی تهنها ژماره بێت.'
});
