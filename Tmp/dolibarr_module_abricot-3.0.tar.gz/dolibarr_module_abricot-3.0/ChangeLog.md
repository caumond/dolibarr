# Abricot - Changelog

## [3.0.0] - 2019-03-06
### FIXED
- Dolibarr 9.x compatiblity
